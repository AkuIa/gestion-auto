<?php

namespace App\Controller;

use App\Entity\Brand;
use App\Form\BrandType;
use App\Repository\BrandRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class BrandController extends AbstractController
{
    #[Route('/brand', name: 'brand.html', methods: ['GET'])]
    public function index(BrandRepository $repository): Response
    {
        $brands = $repository->findAll();
        return $this->render('pages/brand/brand.html.twig', [
            'brands' => $brands,
        ]);
    }

    #[Route('brand/new', methods: ['GET', 'POST'])]
    public function new(Request $request, EntityManagerInterface $manager): Response
    {
        $brand = new Brand();
        $form = $this->createForm(BrandType::class, $brand);

        $form->handleRequest($request);
        if($form->isSubmitted() && $form->isValid()) {
            $brand = $form->getData();
            $manager->persist($brand);
            $manager->flush();
            $this->addFlash('success', 'Brand created successfully');
            return $this->redirectToRoute('brand.html');
        }
        return $this->render('pages/brand/new.html.twig', [
            'form' => $form->createView(),
        ]);
    }

    #[Route('brand/edit/{id}', 'brand.edit', methods: ['GET', 'POST'])]
    public function edit(Request $request, BrandRepository $repository, int $id, EntityManagerInterface $manager): Response
    {
        $brand = $repository->findOneBy(["id" => $id]);
        $form = $this->createForm(BrandType::class, $brand);

        $form->handleRequest($request);
        if($form->isSubmitted() && $form->isValid()) {
            $brand = $form->getData();
            $manager->persist($brand);
            $manager->flush();
            $this->addFlash('success', 'Brand updated successfully');
            return $this->redirectToRoute('brand.html');
        }

        return $this->render('pages/brand/edit.html.twig',[
        'form' => $form->createView()
        ]);
    }

    #[Route('brand/delete/{id}', 'brand.delete', methods: ['GET', 'POST'])]
    public function delete(BrandRepository $repository, EntityManagerInterface $manager, int $id) {
        $brand = $repository->findOneBy(["id" => $id]);
        if($brand) {
            $manager->remove($brand);
            $manager->flush();
            $this->addFlash('success', 'Brand deleted successfully');
        }else{
            $this->addFlash('success', 'Brand not found');
        }
        return $this->redirectToRoute('brand.html');

    }
}