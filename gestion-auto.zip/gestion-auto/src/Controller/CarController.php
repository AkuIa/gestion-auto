<?php

namespace App\Controller;

use App\Entity\Brand;
use App\Entity\Car;
use App\Form\BrandType;
use App\Form\CarType;
use App\Repository\BrandRepository;
use App\Repository\CarRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class CarController extends AbstractController
{
    #[Route('/car', name: 'car.html', methods: ['GET'])]
    public function index(CarRepository $repository): Response
    {
        $cars = $repository->findAll();
        return $this->render('pages/car/car.html.twig', [
            'cars' => $cars,
        ]);
    }

    #[Route('car/new', methods: ['GET', 'POST'])]
    public function new(Request $request, EntityManagerInterface $manager): Response
    {
        $car = new Car();
        $form = $this->createForm(CarType::class, $car);

        $form->handleRequest($request);
        if($form->isSubmitted() && $form->isValid()) {
            $car = $form->getData();
            $manager->persist($car);
            $manager->flush();
            $this->addFlash('success', 'Car created successfully');
            return $this->redirectToRoute('car.html');
        }
        return $this->render('pages/car/new.html.twig', [
            'form' => $form->createView(),
        ]);
    }

    #[Route('car/edit/{id}', 'car.edit', methods: ['GET', 'POST'])]
    public function edit(Request $request, CarRepository $repository, int $id, EntityManagerInterface $manager): Response
    {
        $car = $repository->findOneBy(["id" => $id]);
        $form = $this->createForm(CarType::class, $car);

        $form->handleRequest($request);
        if($form->isSubmitted() && $form->isValid()) {
            $brand = $form->getData();
            $manager->persist($brand);
            $manager->flush();
            $this->addFlash('success', 'Car updated successfully');
            return $this->redirectToRoute('car.html');
        }

        return $this->render('pages/car/edit.html.twig',[
            'form' => $form->createView()
        ]);
    }

    #[Route('car/delete/{id}', 'car.delete', methods: ['GET', 'POST'])]
    public function delete(CarRepository $repository, EntityManagerInterface $manager, int $id) {
        $car = $repository->findOneBy(["id" => $id]);
        if($car) {
            $manager->remove($car);
            $manager->flush();
            $this->addFlash('success', 'Car deleted successfully');
        }else{
            $this->addFlash('success', 'Car not found');
        }
        return $this->redirectToRoute('car.html');

    }
}