<?php

namespace App\Form;

use App\Entity\Brand;
use App\Entity\Car;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\IntegerType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class CarType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        $builder
            ->add('name')
            ->add('year', IntegerType::class, [
                'attr' => [
                    'min' => 1900,
                    'max' => 2023,
                ]
            ])
            ->add('fuel', ChoiceType::class, [
                'label' => 'Fuel',
                'choices' => [
                    'Petrol' => 'petrol',
                    'Diesel' => 'diesel',
                    'Electric' => 'electric',
                ]])
            ->add('color', ChoiceType::class, [
                'label' => 'Color',
                'choices' => [
                    'Black' => 'black',
                    'Blue' => 'blue',
                    'Red' => 'red',
                    'White' => 'white',
                ]])
            ->add('placesNumber', IntegerType::class, [
                'attr' => [
                    'min' => 2,
                    'max' => 7,
                ]
            ])
            ->add('status', ChoiceType::class, [
                'label' => 'Status',
                'choices' => [
                    'Active' => true,
                    'Inactive' => false,
                ],
            ])
            ->add('brand', EntityType::class, [
                'class' => Brand::class,
                'choice_label' => 'name', // Propriété de l'entité Brand à afficher dans la liste déroulante
                'placeholder' => 'Choose a brand', // Texte par défaut de la liste déroulante
            ])
            ->add('submit', SubmitType::class, [
                'label' => 'Confirm',
                'attr' => [
                    'class' => 'btn btn-primary m-4',
                ],
            ])
        ;
    }

    public function configureOptions(OptionsResolver $resolver): void
    {
        $resolver->setDefaults([
            'data_class' => Car::class,
        ]);
    }
}
